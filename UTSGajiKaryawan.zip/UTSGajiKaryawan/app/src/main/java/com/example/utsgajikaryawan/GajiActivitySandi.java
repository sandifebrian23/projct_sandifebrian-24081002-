package com.example.utsgajikaryawan;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class GajiActivitySandi extends AppCompatActivity {

    EditText etNikSandi, etNamaSandi, etGajiPokokSandi, etTunjJabatanSandi, etHariKerjaSandi;
    Button btnHitungSandi, btnKembaliSandi;
    TextView tvTunjMakanSandi, tvTunjTransportSandi, tvGajiKotorSandi, tvGajiBersihSandi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaji_sandi);

        etNikSandi = findViewById(R.id.etNikSandi);
        etNamaSandi = findViewById(R.id.etNamaSandi);
        etGajiPokokSandi = findViewById(R.id.etGajiPokokSandi);
        etTunjJabatanSandi = findViewById(R.id.etTunjJabatanSandi);
        etHariKerjaSandi = findViewById(R.id.etHariKerjaSandi);
        btnHitungSandi = findViewById(R.id.btnHitungSandi);
        btnKembaliSandi = findViewById(R.id.btnKembaliSandi);
        tvTunjMakanSandi = findViewById(R.id.tvTunjMakanSandi);
        tvTunjTransportSandi = findViewById(R.id.tvTunjTransportSandi);
        tvGajiKotorSandi = findViewById(R.id.tvGajiKotorSandi);
        tvGajiBersihSandi = findViewById(R.id.tvGajiBersihSandi);

        btnHitungSandi.setOnClickListener(v -> hitungGaji());
        btnKembaliSandi.setOnClickListener(v -> finish());
    }

    private void hitungGaji() {
        String nik = etNikSandi.getText().toString().trim();
        String nama = etNamaSandi.getText().toString().trim();
        String gajiPokokStr = etGajiPokokSandi.getText().toString().trim();
        String tunjJabatanStr = etTunjJabatanSandi.getText().toString().trim();
        String hariKerjaStr = etHariKerjaSandi.getText().toString().trim();

        // Validasi input kosong
        if (nik.isEmpty()) { etNikSandi.setError("NIK wajib diisi"); return; }
        if (nama.isEmpty()) { etNamaSandi.setError("Nama wajib diisi"); return; }
        if (gajiPokokStr.isEmpty()) { etGajiPokokSandi.setError("Gaji pokok wajib diisi"); return; }
        if (tunjJabatanStr.isEmpty()) { etTunjJabatanSandi.setError("Tunjangan jabatan wajib diisi"); return; }
        if (hariKerjaStr.isEmpty()) { etHariKerjaSandi.setError("Jumlah hari kerja wajib diisi"); return; }

        double gajiPokok = Double.parseDouble(gajiPokokStr);
        double tunjJabatan = Double.parseDouble(tunjJabatanStr);
        double hariKerja = Double.parseDouble(hariKerjaStr);

        // PROSES
        double tunjMakan = hariKerja * 10000;                                   // a. hari kerja x Rp10.000
        double tunjTransport = hariKerja * 5000;                                // b. hari kerja x Rp5.000
        double gajiKotor = gajiPokok + tunjJabatan + tunjMakan + tunjTransport; // c. gaji kotor
        double pajak = 0.10 * gajiKotor;                                        // d. pajak 10%
        double gajiBersih = gajiKotor - pajak;                                  // d. gaji bersih

        // OUTPUT (ditampilkan setelah tombol Hitung diklik)
        tvTunjMakanSandi.setText("Tunjangan Makan : " + rupiah(tunjMakan));
        tvTunjTransportSandi.setText("Tunjangan Transport : " + rupiah(tunjTransport));
        tvGajiKotorSandi.setText("Gaji Kotor : " + rupiah(gajiKotor));
        tvGajiBersihSandi.setText("Gaji Bersih : " + rupiah(gajiBersih));
    }

    private String rupiah(double angka) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        format.setMaximumFractionDigits(0);
        return format.format(angka);
    }
}