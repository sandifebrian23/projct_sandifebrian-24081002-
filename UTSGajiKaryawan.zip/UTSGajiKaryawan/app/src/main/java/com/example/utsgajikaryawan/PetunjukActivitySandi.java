package com.example.utsgajikaryawan;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class PetunjukActivitySandi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petunjuk_sandi);

        Button btnKembali = findViewById(R.id.btnKembaliPetunjukSandi);
        btnKembali.setOnClickListener(v -> finish());
    }
}