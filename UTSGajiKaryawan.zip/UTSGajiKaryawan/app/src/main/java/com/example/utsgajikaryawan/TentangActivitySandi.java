package com.example.utsgajikaryawan;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TentangActivitySandi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_sandi);

        Button btnKembali = findViewById(R.id.btnKembaliTentangSandi);
        btnKembali.setOnClickListener(v -> finish());
    }
}