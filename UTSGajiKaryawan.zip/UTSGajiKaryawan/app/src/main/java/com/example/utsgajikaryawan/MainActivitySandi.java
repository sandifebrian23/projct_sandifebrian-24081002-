package com.example.utsgajikaryawan;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivitySandi extends AppCompatActivity {

    Button btnGajiSandi, btnPetunjukSandi, btnTentangSandi, btnExitSandi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_sandi);

        btnGajiSandi = findViewById(R.id.btnGajiSandi);
        btnPetunjukSandi = findViewById(R.id.btnPetunjukSandi);
        btnTentangSandi = findViewById(R.id.btnTentangSandi);
        btnExitSandi = findViewById(R.id.btnExitSandi);

        btnGajiSandi.setOnClickListener(v ->
                startActivity(new Intent(MainActivitySandi.this, GajiActivitySandi.class)));

        btnPetunjukSandi.setOnClickListener(v ->
                startActivity(new Intent(MainActivitySandi.this, PetunjukActivitySandi.class)));

        btnTentangSandi.setOnClickListener(v ->
                startActivity(new Intent(MainActivitySandi.this, TentangActivitySandi.class)));

        btnExitSandi.setOnClickListener(v ->
                new AlertDialog.Builder(MainActivitySandi.this)
                        .setTitle("Exit")
                        .setMessage("Yakin ingin keluar dari aplikasi?")
                        .setPositiveButton("Ya", (dialog, which) -> finishAffinity())
                        .setNegativeButton("Tidak", null)
                        .show());
    }
}